package com.cg.repo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entity.Product;


@Repository
public class ProductRepoImpl implements ProductRepo {
	@PersistenceContext(unitName = "SpringJPA")
	private EntityManager em;

	@Transactional(propagation = Propagation.REQUIRED)
	public Product saveProduct(Product p) {
		em.persist(p);
		System.out.println("Product saved successfully");
		return p;
	}


	@Transactional
	public List<Product> getAll() {
		return em.createQuery("from Product").getResultList();
	}

}
